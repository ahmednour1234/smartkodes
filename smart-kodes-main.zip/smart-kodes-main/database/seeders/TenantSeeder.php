<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class TenantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \Illuminate\Support\Facades\DB::table('tenants')->insert([
            'id' => (string) \Illuminate\Support\Str::ulid(),
            'name' => 'Default Tenant',
            'slug' => 'default',
            'domain' => null,
            'status' => 0,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
