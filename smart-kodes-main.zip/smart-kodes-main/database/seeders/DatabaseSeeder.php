<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            TenantSeeder::class,
            PlanSeeder::class,
            RoleSeeder::class,
            PermissionSeeder::class,
        ]);

        // Create Super Admin user (platform owner)
        $superAdminUserId = (string) \Illuminate\Support\Str::ulid();
        \Illuminate\Support\Facades\DB::table('users')->insert([
            'id' => $superAdminUserId,
            'tenant_id' => null, // Super admin is not tied to a specific tenant
            'name' => 'Super Admin',
            'email' => 'superadmin@smartkodes.com',
            'password' => \Illuminate\Support\Facades\Hash::make('password'),
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Create Tenant Admin user for default tenant
        $tenantId = \Illuminate\Support\Facades\DB::table('tenants')->where('slug', 'default')->value('id');
        $tenantAdminRoleId = \Illuminate\Support\Facades\DB::table('roles')->where('slug', 'tenant_admin')->value('id');

        $tenantAdminUserId = (string) \Illuminate\Support\Str::ulid();
        \Illuminate\Support\Facades\DB::table('users')->insert([
            'id' => $tenantAdminUserId,
            'tenant_id' => $tenantId,
            'name' => 'Tenant Admin',
            'email' => 'admin@default.com',
            'password' => \Illuminate\Support\Facades\Hash::make('password'),
            'email_verified_at' => now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Assign Super Admin role to super admin user (assign to default tenant for access)
        $superAdminRoleId = \Illuminate\Support\Facades\DB::table('roles')->where('slug', 'super_admin')->value('id');
        $defaultTenantId = \Illuminate\Support\Facades\DB::table('tenants')->where('slug', 'default')->value('id');
        \Illuminate\Support\Facades\DB::table('role_user')->insert([
            'tenant_id' => $defaultTenantId,
            'role_id' => $superAdminRoleId,
            'user_id' => $superAdminUserId,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
