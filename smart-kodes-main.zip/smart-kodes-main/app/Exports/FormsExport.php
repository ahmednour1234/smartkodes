<?php

namespace App\Exports;

use App\Models\Form;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class FormsExport implements FromQuery, WithHeadings, WithMapping, WithStyles, ShouldAutoSize
{
    protected $tenantId;
    protected $filters;

    public function __construct($tenantId, $filters = [])
    {
        $this->tenantId = $tenantId;
        $this->filters = $filters;
    }

    public function query()
    {
        $query = Form::query()
            ->where('tenant_id', $this->tenantId)
            ->withCount('records');

        if (isset($this->filters['status']) && $this->filters['status'] !== '') {
            $query->where('status', $this->filters['status']);
        }

        return $query->latest();
    }

    public function headings(): array
    {
        return [
            'ID',
            'Name',
            'Version',
            'Status',
            'Fields Count',
            'Records Count',
            'Last Modified',
            'Created At',
        ];
    }

    public function map($form): array
    {
        $schema = is_string($form->schema) ? json_decode($form->schema, true) : $form->schema;
        $fieldsCount = isset($schema['fields']) && is_array($schema['fields']) ? count($schema['fields']) : 0;

        return [
            $form->id,
            $form->name,
            $form->version ?? '1.0',
            $this->getStatusLabel($form->status),
            $fieldsCount,
            $form->records_count ?? 0,
            $form->updated_at->format('Y-m-d H:i:s'),
            $form->created_at->format('Y-m-d H:i:s'),
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }

    private function getStatusLabel($status): string
    {
        return match ($status) {
            0 => 'Draft',
            1 => 'Active',
            2 => 'Archived',
            default => 'Draft'
        };
    }
}
