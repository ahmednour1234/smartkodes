<nav class="fixed top-0 left-0 h-full w-64 bg-blue-800 text-white overflow-y-auto">
    <div class="p-4">
        <h1 class="text-xl font-bold">Smart Kodes</h1>
        <p class="text-sm text-blue-200">{{ session('tenant_context.current_tenant') ? session('tenant_context.current_tenant')->name : 'Tenant Portal' }}</p>
        <p class="text-xs text-blue-300 mt-1">{{ Auth::user()->name }}</p>
    </div>
    <ul class="mt-8 space-y-1">
        <li>
            <a href="{{ route('tenant.dashboard') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.dashboard') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.projects.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.projects.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-project-diagram mr-2"></i>Projects
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.forms.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.forms.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-file-alt mr-2"></i>Forms
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.work-orders.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.work-orders.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-clipboard-list mr-2"></i>Workforce
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.records.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.records.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-database mr-2"></i>Records
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.files.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.files.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-file-upload mr-2"></i>Files
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.users.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.users.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-users mr-2"></i>Users
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.reports.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.reports.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-chart-bar mr-2"></i>Reports
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.billing.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.billing.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-credit-card mr-2"></i>Billing
            </a>
        </li>

        <li>
            <a href="{{ route('tenant.notifications.index') }}" class="block px-4 py-2 hover:bg-blue-700 {{ request()->routeIs('tenant.notifications.*') ? 'bg-blue-700' : '' }}">
                <i class="fas fa-bell mr-2"></i>Notifications
            </a>
        </li>
    </ul>
    <div class="absolute bottom-0 w-full p-4">
        <form method="POST" action="{{ route('logout') }}" class="w-full">
            @csrf
            <button type="submit" class="block w-full text-left px-4 py-2 hover:bg-blue-700 rounded transition-colors">
                <i class="fas fa-sign-out-alt mr-2"></i>Logout
            </button>
        </form>
    </div>
</nav>
